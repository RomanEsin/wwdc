//#-hidden-code
import UIKit
import PlaygroundSupport
import BubbleSort

var shouldSet = false

func setFunction() {
    shouldSet = true
}

var test = true
//#-end-hidden-code
/*:
 # Bubble Sort
 Bubble sort is a simple sorting algorithms that repeatedly steps through the array and compares adjacent elements.
 Keep in mind, that this sorting algorithm performs poorly in real world use due to it's inefficiency.
 
 **Run the playground to see the visualization of how bubble sort works.**
 */

// You can change the array that will be sorted.
let vc = BubbleViewController([/*#-editable-code*/2, 4, 1, 5, 3/*#-end-editable-code*/])

//#-hidden-code
@discardableResult
//#-end-hidden-code
func bubbleSort(_ array: SortArray) -> [Int] {
    //#-hidden-code
    let array = array
    main:
    //#-end-hidden-code
    // Loop for each number.
    for i in 0..<array.count {
        // Sort each number from end to start.
        for j in 1..<array.count - i {
            if array[j] < array[j - 1] {
                // Uncomment the line below when you want to try your algorithm.
                //#-hidden-code
            if test {
                //#-end-hidden-code
                //#-editable-code
                // setFunction()
                //#-end-editable-code
                //#-hidden-code
            } else {
                //#-end-hidden-code
                //#-editable-code
                <#Put your code here#>
                //#-end-editable-code
                //#-hidden-code
            }
                //#-end-hidden-code
                //#-hidden-code
                array.queue.append(QueueItem(index: j, (array[j], array[j - 1])))
                //#-end-hidden-code
            }
            //#-hidden-code
            else {
                array.queue.append(QueueItem(index: j, nil))
            }
            //#-end-hidden-code
        }
    }
    //#-hidden-code
    //#-end-hidden-code
    return array.array
}

//#-hidden-code
bubbleSort(SortArray([3, 1, 2]))
test = false
if shouldSet {
    vc.function = bubbleSort
}
PlaygroundPage.current.setLiveView(vc)
//#-end-hidden-code

//: [Next](@next)
