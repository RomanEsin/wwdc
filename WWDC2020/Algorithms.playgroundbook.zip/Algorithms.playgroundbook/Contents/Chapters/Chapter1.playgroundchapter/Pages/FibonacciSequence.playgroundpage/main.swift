//#-hidden-code
import UIKit
import PlaygroundSupport
import Fibonacci

var shouldSet = false

func setFunction() {
    shouldSet = true
}

var test = true
//#-end-hidden-code
/*:
 # Nth Fibonacci number
 Fibonacci sequence is a sequence of numbers, where each next number is a sum of previous two.
 This is a fragment of the sequence: **0, 1, 1, 2, 3, 5, 8, 13, 21, 34**
 
 **Run the playground to see the visualization of the Fibonacci sequence.**
 */

//#-hidden-code
guard
    //#-end-hidden-code
// You can change the N that you would want to iterate to.
let vc = FibonacciViewControler(countTo: /*#-editable-code*/7/*#-end-editable-code*/)
    //#-hidden-code
    else { PlaygroundPage.current.finishExecution() }
//#-end-hidden-code

func nthFibonacci(_ n: Number) -> Int {
    var nCount = 0
    // F is the first number.
    var f = 0
    // S is the second number.
    var s = 1
    //#-hidden-code
    let totalN = n.value
    //#-end-hidden-code
    // This loop will continue until you've reached count N.
    while nCount <= n {
        //#-hidden-code
        if nCount % 2 == 0 {
            n.queue.append((s, f))
        } else {
            n.queue.append((f, s))
        }
        //#-end-hidden-code
        // Uncomment the line below when you want to try your algorithm.
        //#-hidden-code
    if test {
        //#-end-hidden-code
        //#-editable-code
        // setFunction()
        //#-end-editable-code
        //#-hidden-code
    } else {
        //#-end-hidden-code
        //#-editable-code
        <#Put your code here#>
        //#-end-editable-code
        //#-hidden-code
    }
        //#-end-hidden-code
        nCount += 1
    }
    return f
}

//#-hidden-code
nthFibonacci(Number(2))
test = false
if shouldSet {
    vc.function = nthFibonacci
}
PlaygroundPage.current.setLiveView(vc)
//#-end-hidden-code

//: [Next](@next)
