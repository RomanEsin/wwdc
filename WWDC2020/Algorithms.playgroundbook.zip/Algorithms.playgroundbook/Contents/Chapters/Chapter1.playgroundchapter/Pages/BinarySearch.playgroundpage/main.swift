//#-hidden-code
import UIKit
import PlaygroundSupport
import BinarySearch

var shouldSet = false

func setFunction() {
    shouldSet = true
}

var test = true
//#-end-hidden-code
/*:
 # Binary Search
 This is your final challenge. Binary search is very fast search algorithms.
 It gets a sorted array and a number to search for as an input and outputs the index of this number in the array.
 
 **Run the playground to see the visualization of binary search.**
 */

// You can change the array of given numbers and the number to search for.
let vc = BinarySearchViewController([/*#-editable-code*/1, 2, 3, 4, 5, 6, 7, 8, 9, 10/*#-end-editable-code*/], searchFor: /*#-editable-code*/4/*#-end-editable-code*/)

//#-hidden-code
@discardableResult
//#-end-hidden-code
public func binarySearch(_ array: SearchArray, _ value: Int) -> Int? {
    var low = 0
    var high = array.count - 1
    //#-hidden-code
    var prevLow: Int? = nil
    var prevHigh: Int? = nil
    var shouldEnd = false
    //#-end-hidden-code
    while low <= high {
        // Get the middle index of array.
        let mid = (low + high) / 2
        //#-hidden-code
        prevLow = low
        prevHigh = high
        //#-end-hidden-code
        // Check if middle number is chosen number and return middle index if so.
        if array[mid] == value {
            //#-hidden-code
            array.setBounds(mid, r: mid)
            //#-end-hidden-code
            return mid
        }
        // Uncomment the line below when you want to try your algorithm.
        //#-hidden-code
    if test {
        //#-end-hidden-code
        //#-editable-code
        // setFunction()
        //#-end-editable-code
        //#-hidden-code
    } else {
        //#-end-hidden-code
        if value > array[mid] {
            //#-editable-code
            <#Put your code here#>
            //#-end-editable-code
        }
        if value < array[mid] {
            //#-editable-code
            <#Put your code here#>
            //#-end-editable-code
        }
        //#-hidden-code
    }
        array.setBounds(low, r: high)
        
        shouldEnd = prevLow == low && prevHigh == high
        
        if shouldEnd {
            return nil
        }
        //#-end-hidden-code
    }
    return nil
}

//#-hidden-code
binarySearch(SearchArray([1, 2, 3]), 1)
test = false
if shouldSet {
    vc.function = binarySearch
}
PlaygroundPage.current.setLiveView(vc)
//#-end-hidden-code

/*:
 This is the end of this playground!
 
 I hope you had fun and used as little hints as possible!
 
 **Have a good day, and keep exploring beatiful world of algorithms!**
 */
