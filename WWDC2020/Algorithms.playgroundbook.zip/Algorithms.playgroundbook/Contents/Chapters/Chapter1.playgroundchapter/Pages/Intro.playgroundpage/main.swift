/*:
 # Hello and welcome **Algorithms** to this playground!
 
 An **algorithm** is a sequence of well-defined instructions, that solve a calss of problems or perform a computation.
 
 In this playgroiund you'll cover the basics of programming algorithms.
 You will be given 3 challenges to complete,
 they require basic understanding of loops and functions:
 1. [Nth Fibonacci number](FibonacciSequence)
 2. [Bubble Sort](BubbleSort)
 3. [Binary Search](BinarySearch)
 
 Every algorithm will have visual and textual explanation,
 then you'll need to fill in the missing code to complete the algorithm.
 If you're stuck, you can ues hints. Good luck!
 
 [Next](@next)
 */
