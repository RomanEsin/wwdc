import UIKit
import PlaygroundSupport
import AudioToolbox

public struct QueueItem {
    var index: Int
    var left: Int
    var right: Int
}

// MARK: - SearchArray
public class SearchArray: Collection {
    
    var queue: [QueueItem] = []
    var prev: Int?
    
    public var array: [Int]
    public func index(after i: Int) -> Int {
        return array.index(after: i)
    }
    
    public var startIndex: Int { array.startIndex }
    public var endIndex: Int { array.endIndex }
    
    public func setBounds(_ l: Int, r: Int) {
        queue[queue.count - 1].left = l
        queue[queue.count - 1].right = r
    }
    
    public func addSubscript(_ index: Int) {
        queue.append(QueueItem(index: index, left: 0, right: 0))
    }
    
    func copy() -> SearchArray {
        return SearchArray(array)
    }
    
    public subscript(index: Int) -> Int {
        if prev != index {
            addSubscript(index)
            prev = index
        }
        return array[index]
    }
    
    public init(_ array: [Int]) {
        self.array = array
    }
}

public func binarySearchTest(array: SearchArray, value: Int) -> Int? {
    var low = 0
    var high = array.count - 1
    while low <= high {
        let mid = (low + high) / 2
        if array[mid] == value {
            array.setBounds(mid, r: mid)
            return mid
        } else if array[mid] < value {
            low = mid + 1
        } else if array[mid] > value {
            high = mid - 1
        }
        array.setBounds(low, r: high)
    }
    return nil
}

//  var array = [1, 2, 3, 4, 5, 6, 7]
//  binarySearchTest(array: SearchArray(array), value: 1)

public struct SearchTest {
    var array: SearchArray
    var sValue: Int
    var sIndex: Int
}

// MARK: - Array View
public class ArrayView: UIView {
    var array: SearchArray
    var arrayLabels: [UILabel]
    var indices: [UILabel]
    
    var valuesLabel: UILabel
    var indexLabel: UILabel
    
    var leadingConstraint: NSLayoutConstraint!
    var trailingConstraint: NSLayoutConstraint!
    
    func setLeadingTo(_ index: Int) {
        UIView.animate(withDuration: 1, delay: 0, options: .curveEaseInOut, animations: {
            self.arrayLabels[0..<index].forEach { $0.alpha = 0 }
            self.indices[0..<index].forEach { $0.alpha = 0 }
        }, completion: nil)
        leadingConstraint.isActive = false
        leadingConstraint = leadingAnchor.constraint(equalTo: arrayLabels[index].leadingAnchor, constant: -8)
        leadingConstraint.isActive = true
    }
    
    func setTrailingTo(_ index: Int) {
        UIView.animate(withDuration: 1, delay: 0, options: .curveEaseInOut, animations: {
            self.arrayLabels[index + 1..<self.arrayLabels.count].forEach { $0.alpha = 0 }
            self.indices[index + 1..<self.arrayLabels.count].forEach { $0.alpha = 0 }
        }, completion: nil)
        trailingConstraint.isActive = false
        trailingConstraint = trailingAnchor.constraint(equalTo: arrayLabels[index].trailingAnchor, constant: 8)
        trailingConstraint.isActive = true
    }
    
    init(_ array: SearchArray) {
        self.array = array
        arrayLabels = []
        indices = []
        
        valuesLabel = UILabel()
        valuesLabel.translatesAutoresizingMaskIntoConstraints = false
        valuesLabel.textAlignment = .center
        valuesLabel.font = .systemFont(ofSize: 28, weight: .bold)
        valuesLabel.text = "Values"
        valuesLabel.textColor = .label
        
        indexLabel = UILabel()
        indexLabel.translatesAutoresizingMaskIntoConstraints = false
        indexLabel.textAlignment = .center
        indexLabel.font = .systemFont(ofSize: 28, weight: .regular)
        indexLabel.text = "Indices"
        indexLabel.textColor = .tertiaryLabel
        
        super.init(frame: .zero)
        
        translatesAutoresizingMaskIntoConstraints = false
        
        var counter = -1
        let w = UILabel()
        w.translatesAutoresizingMaskIntoConstraints = false
        w.font = .monospacedDigitSystemFont(ofSize: 28, weight: .bold)
        w.text = String(array[array.count - 1])
        w.alpha = 0
        addSubview(w)
        
        for value in array {
            counter += 1
            
            let label = UILabel()
            label.translatesAutoresizingMaskIntoConstraints = false
            label.textAlignment = .center
            label.font = .monospacedDigitSystemFont(ofSize: 28, weight: .bold)
            label.text = String(value)
            label.textColor = .label
            
            let ind = UILabel()
            ind.translatesAutoresizingMaskIntoConstraints = false
            ind.font = .monospacedDigitSystemFont(ofSize: 28, weight: .regular)
            ind.text = String(counter)
            ind.textColor = .tertiaryLabel
            
            addSubview(label)
            addSubview(ind)
            
            if arrayLabels.count == 0 {
                NSLayoutConstraint.activate([
                    label.widthAnchor.constraint(equalTo: w.widthAnchor),
                    ind.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 6),
                    ind.centerXAnchor.constraint(equalTo: label.centerXAnchor),
                    topAnchor.constraint(equalTo: label.topAnchor),
                    bottomAnchor.constraint(equalTo: ind.bottomAnchor)
                ])
            } else {
                NSLayoutConstraint.activate([
                    label.leadingAnchor.constraint(equalTo: arrayLabels.last!.trailingAnchor, constant: 4),
                    label.widthAnchor.constraint(equalTo: w.widthAnchor),
                    ind.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 6),
                    ind.centerXAnchor.constraint(equalTo: label.centerXAnchor)
                ])
            }
            
            indices.append(ind)
            arrayLabels.append(label)
        }
        
        leadingConstraint = leadingAnchor.constraint(equalTo: arrayLabels[0].leadingAnchor, constant: -8)
        trailingConstraint = trailingAnchor.constraint(equalTo: arrayLabels.last!.trailingAnchor, constant: 8)
        
        addSubview(valuesLabel)
        addSubview(indexLabel)
        
        NSLayoutConstraint.activate([
            leadingConstraint,
            trailingConstraint,
            valuesLabel.bottomAnchor.constraint(equalTo: arrayLabels[0].topAnchor, constant: -12),
            valuesLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            indexLabel.topAnchor.constraint(equalTo: indices[0].bottomAnchor, constant: 12),
            indexLabel.centerXAnchor.constraint(equalTo: centerXAnchor)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

// MARK: - BinSearchVC
public class BinarySearchViewController: UIViewController {
    public var function: ((SearchArray, Int) -> Int?)?
    var tests = [
        SearchTest(array: SearchArray([1, 4, 7, 8, 9, 11, 15, 18]), sValue: 1, sIndex: 0),
        SearchTest(array: SearchArray([1, 4, 7, 8, 9, 11]), sValue: 11, sIndex: 5),
        SearchTest(array: SearchArray([1, 4, 7, 8, 9, 11, 15, 18]), sValue: 7, sIndex: 2),
        SearchTest(array: SearchArray([1, 4, 7, 8, 9, 11, 15, 18]), sValue: 18, sIndex: 7)
    ]
    
    var arrayViews: [ArrayView] = []
    var array: SearchArray
    var targetValue: Int
    
    var hints = ["You can change the `low` and `high` bounds.", "Set the `low` bound to `mid + 1` and the `high` bound to `mid - 1`.", """
Solution:
```
if value > array[mid] {
    low = mid + 1
}
if value < array[mid] {
    high = mid - 1
}
```
"""]
    let tutorials = [
        "At first you take the middle of the array and compare it to the given number and return it's index if in matches.",
        "Because the array is sorted, we can compare the middle of the array with the number.",
        "If the given number is lower than the middle, we can drop all the numbers after the middle, otherwise below the middle."
    ]
    var currentTutorial = 0
    
    let startButton: UIButton = {
        let button = UIButton(type: .roundedRect)
        button.tintColor = .systemBlue
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Evaluate", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 24, weight: .medium)
        
        button.addTarget(self, action: #selector(evaluate), for: .touchUpInside)
        return button
    }()
    
    let hintsButton: UIButton = {
        let button = UIButton(type: .roundedRect)
        button.tintColor = .systemBlue
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Show Hints", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 20, weight: .regular)
        
        button.addTarget(self, action: #selector(showHints), for: .touchUpInside)
        return button
    }()
    
    // MARK: - ViewDidLoad
    public override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        
        // The playgrounds wouldn't compile a simple layer addition to stored property
        // So here's a hack to fix it...
        let background = UIView()
        background.tag = -1
        view.addSubview(background)
        
        let gradient = CAGradientLayer()
        gradient.frame = view.bounds
        gradient.colors = [
            UIColor(white: 0, alpha: 0).cgColor,
            UIColor(white: 0.8, alpha: 0.2).cgColor
        ]
        
        background.layer.addSublayer(gradient)
        
        let arrayView = ArrayView(SearchArray(array.array))
        view.addSubview(arrayView)
        arrayViews.append(arrayView)
        
        view.addSubview(startButton)
        startButton.isHidden = true
        view.addSubview(hintsButton)
        NSLayoutConstraint.activate([
            startButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16),
            startButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),

            hintsButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            hintsButton.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
        
        NSLayoutConstraint.activate([
            arrayViews.first!.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            arrayViews.first!.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if array.array != array.array.sorted() {
            let alert = UIAlertController(title: "Error", message: "Given array should be sorted.", preferredStyle: .alert)
            let close = UIAlertAction(title: "Close", style: .cancel) { (_) in
                PlaygroundPage.current.finishExecution()
            }
            alert.addAction(close)
            present(alert, animated: true, completion: nil)
        }
        
        guard let realTarget = binarySearchTest(array: array.copy(), value: targetValue) else {
            let alert = UIAlertController(title: "Error", message: "\(targetValue) is not in the given array.", preferredStyle: .alert)
            let close = UIAlertAction(title: "Close", style: .cancel) { (_) in
                PlaygroundPage.current.finishExecution()
            }
            alert.addAction(close)
            present(alert, animated: true, completion: nil)
            return
        }
        arrayViews.first!.arrayLabels[realTarget].textColor = .systemGreen
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.evaluate()
        }
//        test()
    }
    
    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // The playgrounds wouldn't compile a simple layer addition to stored property
        // So here's a hack to fix it...
        view.viewWithTag(-1)?.layer.sublayers?.first?.frame = view.bounds
    }
    
    @objc func showHints() {
        PlaygroundPage.current.assessmentStatus = .pass(message: "")
        PlaygroundPage.current.assessmentStatus = .fail(hints: [self.hints[0], self.hints[1]], solution: self.hints[2])
        PlaygroundPage.current.finishExecution()
    }
    
    public func test() {
        guard let searchFunction = function else { return }
        for test in tests {
            let result = searchFunction(test.array, test.sValue)
            if result == test.sIndex {
//              "Pass"
            } else {
//              "Fail"
            }
        }
    }
    
    @objc func restart() {
        startButton.setTitle("Evaluate", for: .normal)
        startButton.removeTarget(nil, action: nil, for: .allEvents)
        startButton.addTarget(self, action: #selector(evaluate), for: .touchUpInside)
        
        let realTarget = binarySearchTest(array: array.copy(), value: targetValue)!
        
        UIView.animate(withDuration: 0.7, delay: 0, options: .curveEaseInOut, animations: {
            self.arrayViews.first!.setLeadingTo(0)
            self.arrayViews.first!.setTrailingTo(self.array.count - 1)
            for (i, _) in self.arrayViews.first!.arrayLabels.enumerated() {
                self.arrayViews.first!.arrayLabels[i].alpha = 1
            }
            for (i, _) in self.arrayViews.first!.indices.enumerated() {
                self.arrayViews.first!.indices[i].alpha = 1
            }
            self.view.layoutIfNeeded()
        }, completion: nil)
        arrayViews.first!.arrayLabels[realTarget].textColor = .systemGreen
    }
    
    // MARK: - Evaluate
    @objc func evaluate() {
        startButton.setTitle("Restart", for: .normal)
        startButton.removeTarget(nil, action: nil, for: .allEvents)
        startButton.isHidden = true
        
        let testArray = array.copy()
        let test2 = testArray.copy()
        let alg = function ?? binarySearchTest
        
        guard let _ = alg(testArray, targetValue), let _ = binarySearchTest(array: array.copy(), value: targetValue) else {
            PlaygroundPage.current.assessmentStatus = .fail(hints: [hints[0], hints[1]], solution: hints[2])
            AudioServicesPlaySystemSound(1050)
            let alert = UIAlertController(title: "Error", message: "You have an error in your algorithm. Use a hint!", preferredStyle: .alert)
            let close = UIAlertAction(title: "Close", style: .cancel)
            alert.addAction(close)
            self.present(alert, animated: true, completion: nil)
            return
        }
        guard let realTarget = binarySearchTest(array: test2, value: targetValue) else {
            PlaygroundPage.current.assessmentStatus = .fail(hints: [hints[0], hints[1]], solution: hints[2])
            return
        }
        arrayViews.first!.arrayLabels[realTarget].textColor = .systemGreen
        var delay: Double = 0
        for item in testArray.queue {
            let index = item.index
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5 * delay * (function == nil ? 2.7 : 1)) {
                if self.function == nil && self.currentTutorial < self.tutorials.count {
                    PlaygroundPage.current.assessmentStatus = .pass(message: self.tutorials[self.currentTutorial])
                    self.currentTutorial += 1
                }
                AudioServicesPlaySystemSound(1105)
                UIView.transition(with: self.arrayViews.first!.arrayLabels[index], duration: 0.3, options: [.transitionCrossDissolve, .curveEaseInOut], animations: {
                    self.arrayViews.first!.arrayLabels[index].textColor = .systemRed
                }, completion: { (_) in
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        UIView.animate(withDuration: 1, delay: 0, options: .curveEaseInOut, animations: {
                            self.arrayViews.first!.setLeadingTo(item.left)
                            self.arrayViews.first!.setTrailingTo(item.right)
                            self.view.layoutIfNeeded()
                        }, completion: nil)
                        UIView.transition(with: self.arrayViews.first!.arrayLabels[index], duration: 0.7, options: [.transitionCrossDissolve, .curveEaseInOut], animations: {
                            self.arrayViews.first!.arrayLabels[index].textColor = index == realTarget ? .systemGreen : .label
                        }, completion: { _ in
                            if index == realTarget {
                                self.startButton.addTarget(self, action: #selector(self.restart), for: .touchUpInside)
                                self.startButton.isHidden = false
                            }
                            if index == realTarget && self.function != nil {
                                AudioServicesPlaySystemSound(1106)
                                PlaygroundPage.current.assessmentStatus = .pass(message: "Great work! The playground is now over. Have a good day and keep exploring the wonderful world of algorithms!")
                            } else if index == realTarget {
                                PlaygroundPage.current.assessmentStatus = .pass(message: "")
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                    PlaygroundPage.current.assessmentStatus = .fail(hints: [self.hints[0], self.hints[1]], solution: self.hints[2])
                                    let alert = UIAlertController(title: "Done", message: "You've watched how Binary search is performed. Now try to complete missing code in the editor, remember that you can use hints! Please close and open the hints menu to see the new hints.", preferredStyle: .alert)
                                    let close = UIAlertAction(title: "Let's go!", style: .default)
                                    alert.addAction(close)
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        })
                    }
                })
            }
            
            delay += 1
        }
    }
    
    public init(_ array: [Int], searchFor value: Int) {
        self.array = SearchArray(array)
        self.targetValue = value
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
