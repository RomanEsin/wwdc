import UIKit
import PlaygroundSupport
import AudioToolbox

// MARK: - Reference function
public func fNumAt(_ i: Number) -> Int {
    let n = i.value
    var counter = 0
    var f = 0
    var s = 1
    while counter <= n {
        if counter % 2 == 0 {
            i.queue.append((s, f))
        } else {
            i.queue.append((f, s))
        }
        s += f
        f = s - f
        counter += 1
    }
    return f
}

public func <=(lhs: Int, rhs: Number) -> Bool {
    return lhs <= rhs.value
}

// MARK: - Number
public class Number {
    
    public var value: Int
    public var queue: [(Int, Int)] = []
    
    public func copy() -> Number {
        return Number(value)
    }
    
    public init(_ value: Int) {
        self.value = value
    }
}

// MARK: - Fibonacci VC
public class FibonacciViewControler: UIViewController {
    public var function: ((Number) -> Int)?
    
    var targetValue: Int
    var queue: [(Int, Int)] = []
    
    var counterLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "N: 0"
        label.font = .monospacedSystemFont(ofSize: 30, weight: .regular)
        label.textColor = .secondaryLabel
        
        return label
    }()
    
    var firstLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "1"
        label.font = .monospacedSystemFont(ofSize: 30, weight: .regular)
        label.textColor = .label
        
        return label
    }()
    var secondLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "0"
        label.font = .monospacedSystemFont(ofSize: 30, weight: .regular)
        label.textColor = .systemGreen
        
        return label
    }()
    
    var completions: [(Bool, @escaping () -> ()) -> ()] = []
    var currentN = 0 {
        didSet {
            UIView.transition(with: counterLabel, duration: 0.3, options: [.transitionCrossDissolve, .curveEaseInOut], animations: {
                self.counterLabel.text = "N: " + String(self.currentN)
            })
        }
    }
    
    let startButton: UIButton = {
        let button = UIButton(type: .roundedRect)
        button.tintColor = .systemBlue
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Evaluate", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 24, weight: .medium)
        
        button.addTarget(self, action: #selector(evaluate), for: .touchUpInside)
        return button
    }()
    
    let hintsButton: UIButton = {
        let button = UIButton(type: .roundedRect)
        button.tintColor = .systemBlue
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Show Hints", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 20, weight: .regular)
        
        button.addTarget(self, action: #selector(showHints), for: .touchUpInside)
        return button
    }()
    
    let hints = ["Create a temporary variable to store the sum of `f` and `s`.", "Set `f` equal to `s` and `s` equal to that temporary variable.", """
    Solution:
    ```
    let tmp = f + s
    f = s
    s = tmp
    ```
    """]
    
    let tutorials = [
        "The green number is the Nth number in Fibonacci sequence.",
        "As in the Fibonacci sequence, each next number is a sum of previous two.",
        "Now look at how it progresses to the given N."
    ]
    
    // MARK: - ViewDidLoad
    public override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        
        view.addSubview(counterLabel)
        view.addSubview(firstLabel)
        view.addSubview(secondLabel)
        
        // The playgrounds wouldn't compile a simple layer addition to stored property
        // So here's a hack to fix it...
        let background = UIView()
        background.tag = -1
        view.insertSubview(background, belowSubview: counterLabel)
        
        let gradient = CAGradientLayer()
        gradient.frame = view.bounds
        gradient.colors = [
            UIColor(white: 0, alpha: 0).cgColor,
            UIColor(white: 0.8, alpha: 0.2).cgColor
        ]
        
        background.layer.addSublayer(gradient)
        
        NSLayoutConstraint.activate([
            firstLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            firstLabel.trailingAnchor.constraint(equalTo: view.centerXAnchor, constant: -16),
            
            secondLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            secondLabel.leadingAnchor.constraint(equalTo: view.centerXAnchor, constant: 16),
            
            counterLabel.bottomAnchor.constraint(equalTo: firstLabel.topAnchor, constant: -16),
            counterLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
        
        view.addSubview(startButton)
        view.addSubview(hintsButton)
        startButton.isHidden = true
        NSLayoutConstraint.activate([
            startButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16),
            startButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            hintsButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            hintsButton.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.evaluate()
        }
    }
    
    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // The playgrounds wouldn't compile a simple layer addition to stored property
        // So here's a hack to fix it...
        view.viewWithTag(-1)?.layer.sublayers?.first?.frame = view.bounds
    }
    
    @objc func showHints() {
        PlaygroundPage.current.assessmentStatus = .pass(message: "")
        PlaygroundPage.current.assessmentStatus = .fail(hints: [self.hints[0], self.hints[1]], solution: self.hints[2])
        PlaygroundPage.current.finishExecution()
    }
    
    // MARK: - Restart
    @objc func restart() {
        startButton.setTitle("Evaluate", for: .normal)
        startButton.removeTarget(nil, action: nil, for: .allEvents)
        startButton.addTarget(self, action: #selector(evaluate), for: .touchUpInside)
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut, animations: {
            self.secondLabel.textColor = .systemGreen
            self.firstLabel.textColor = .label
        }, completion: nil)
        UIView.transition(with: firstLabel, duration: 0.3, options: [.transitionCrossDissolve, .curveEaseInOut], animations: {
            self.firstLabel.text = "1"
        }, completion: nil)
        UIView.transition(with: secondLabel, duration: 0.3, options: [.transitionCrossDissolve, .curveEaseInOut], animations: {
            self.secondLabel.text = "0"
        }, completion: nil)
        currentN = 0
    }
    
    // MARK: - Evaluate
    @objc func evaluate() {
        startButton.setTitle("Restart", for: .normal)
        startButton.removeTarget(nil, action: nil, for: .allEvents)
        self.startButton.isHidden = true
        if let f = function {
            let num = Number(targetValue)
            let _ = f(num)
            queue = num.queue
        } else {
            let num = Number(targetValue)
            let _ = fNumAt(num)
            queue = num.queue
        }
        for _ in 1...targetValue {
            addCompletion()
        }
        performAnimations()
    }
    
    // MARK: - Perform animation
    @objc func performAnimations() {
        if completions.first == nil {
            startButton.addTarget(self, action: #selector(restart), for: .touchUpInside)
            startButton.isHidden = false
            if let f = function, f(Number(targetValue)) == fNumAt(Number(targetValue)) {
                AudioServicesPlaySystemSound(1106)
                PlaygroundPage.current.assessmentStatus = .pass(message: "Great work! You can now [continue](@next)!")
            } else {
                if function != nil {
                    PlaygroundPage.current.assessmentStatus = .fail(hints: [hints[0], hints[1]], solution: hints[2])
                    AudioServicesPlaySystemSound(1050)
                    let alert = UIAlertController(title: "Error", message: "You have an error in your algorithm. Use a hint!", preferredStyle: .alert)
                    let close = UIAlertAction(title: "Close", style: .cancel)
                    alert.addAction(close)
                    self.present(alert, animated: true, completion: nil)
                } else {
                    PlaygroundPage.current.assessmentStatus = .pass(message: "")
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                        PlaygroundPage.current.assessmentStatus = .fail(hints: [self.hints[0], self.hints[1]], solution: self.hints[2])
                        let alert = UIAlertController(title: "Done", message: "You've watched how Nth Fibonacci number is found. Now try to complete missing code in the editor, remember that you can use hints! Please close and open the hints menu to see the new hints.", preferredStyle: .alert)
                        let close = UIAlertAction(title: "Let's go!", style: .default)
                        alert.addAction(close)
                        self.present(alert, animated: true, completion: nil)
                    }
                }
            }
        }
        
        if function == nil && currentN < tutorials.count {
            PlaygroundPage.current.assessmentStatus = .pass(message: tutorials[currentN])
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.8) {
                self.completions.first?(self.currentN % 2 == 1) {
                    let _ = self.completions.removeFirst()
                    self.performAnimations()
                    if self.function == nil {
                        //                      PlaygroundPage.current.assessmentStatus = .fail(hints: [self.hints[self.currentN]], solution: nil)
                    }
                }
            }
        } else {
            completions.first?(currentN % 2 == 1) {
                let _ = self.completions.removeFirst()
                self.performAnimations()
            }
        }
    }
    
    func addCompletion() {
        completions.append(animate)
    }
    
    // MARK: - Animate
    func animate(_ right: Bool = true, _ completion: @escaping () -> ()) {
        let copy = UILabel()
        copy.translatesAutoresizingMaskIntoConstraints = false
        copy.font = .monospacedSystemFont(ofSize: 30, weight: .regular)
        copy.textColor = .systemGreen
        copy.alpha = 0.8
        
        view.insertSubview(copy, belowSubview: secondLabel)
        
        var first: NSLayoutConstraint!
        var second: NSLayoutConstraint!
        
        let pair = queue[currentN]
        
        if right {
            first = copy.trailingAnchor.constraint(equalTo: firstLabel.trailingAnchor)
            second = copy.leadingAnchor.constraint(equalTo: secondLabel.leadingAnchor)
            
            copy.text = String(pair.0)
            
            UIView.transition(with: self.firstLabel, duration: 0.3, options: [.transitionCrossDissolve, .curveEaseInOut], animations: {
                self.firstLabel.textColor = .label
            }, completion: nil)
        } else {
            first = copy.leadingAnchor.constraint(equalTo: secondLabel.leadingAnchor)
            second = copy.trailingAnchor.constraint(equalTo: firstLabel.trailingAnchor)
            
            copy.text = String(pair.1)
            
            UIView.transition(with: self.secondLabel, duration: 0.3, options: [.transitionCrossDissolve, .curveEaseInOut], animations: {
                self.secondLabel.textColor = .label
            }, completion: nil)
        }
        copy.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        first.isActive = true
        view.layoutSubviews()
        first.isActive = false
        second.isActive = true
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            if right {
                UIView.transition(with: self.secondLabel, duration: 0.3, options: [.transitionCrossDissolve, .curveEaseInOut], animations: {
                    self.secondLabel.textColor = .systemGreen
                }, completion: nil)
            } else {
                UIView.transition(with: self.firstLabel, duration: 0.3, options: [.transitionCrossDissolve, .curveEaseInOut], animations: {
                    self.firstLabel.textColor = .systemGreen
                }, completion: nil)
            }
        }
        
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseInOut, animations: {
            self.view.layoutIfNeeded()
        }, completion: { (_) in
            if right {
                UIView.transition(with: self.secondLabel, duration: 0.3, options: [.transitionCrossDissolve, .curveEaseInOut], animations: {
                    self.secondLabel.text = String(pair.1)
                }, completion: nil)
            } else {
                UIView.transition(with: self.firstLabel, duration: 0.3, options: [.transitionCrossDissolve, .curveEaseInOut], animations: {
                    self.firstLabel.text = String(pair.0)
                }, completion: nil)
            }
            copy.removeFromSuperview()
            self.currentN += 1
            AudioServicesPlaySystemSound(1105)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                completion()
            }
        })
    }
    
    public init?(countTo value: Int) {
        guard value > 0 else {
            PlaygroundPage.current.finishExecution()
            return nil
        }
        self.targetValue = value
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
