import UIKit
import PlaygroundSupport
import AudioToolbox

// MARK: - Reference algorithm
func bubbleSort(_ array: SortArray) -> [Int] {
    let array = array
    for i in 0..<array.count {
        for j in 1..<array.count - i {
            if array[j] < array[j - 1] {
                let tmp = array[j - 1]
                array[j - 1] = array[j]
                array[j] = tmp
                
                array.queue.append(QueueItem(index: j, (array[j], array[j - 1])))
            }
            else {
                array.queue.append(QueueItem(index: j, nil))
            }
        }
    }
    return array.array
}

public struct QueueItem {
    public let index: Int
    public let values: (Int, Int)?
    public var isTutorial = false
    
    public init(index: Int, _ values: (Int, Int)?) {
        self.index = index
        self.values = values
    }
}

// MARK: - Sort array
public class SortArray: Collection {
    
    public var queue: [QueueItem] = []
    
    public var array: [Int]
    public func index(after i: Int) -> Int {
        return array.index(after: i)
    }
    
    public var startIndex: Int { array.startIndex }
    public var endIndex: Int { array.endIndex }
    
    func copy() -> SortArray {
        return SortArray(array)
    }
    
    public subscript(index: Int) -> Int {
        get {
            return array[index]
        }
        set {
            array[index] = newValue
        }
    }
    
    public init(_ array: [Int]) {
        self.array = array
    }
}

// MARK: - Array view
public class ArrayView: UIView {
    var array: SortArray
    var arrayLabels: [UILabel]
    var centerYs: [NSLayoutConstraint]
    var indices: [UILabel]
    
    var leadingConstraint: NSLayoutConstraint!
    var trailingConstraint: NSLayoutConstraint!
    
    var speed = 0.4
    
    public func set(_ i: Int, to color: UIColor) {
        UIView.transition(with: self.arrayLabels[i], duration: 0.2, options: [.transitionCrossDissolve, .curveEaseInOut], animations: {
            self.arrayLabels[i].textColor = color
        })
    }
    
    // MARK: - Highlight
    public func highlight(_ i: Int, with color: UIColor = .systemRed) {
        UIView.transition(with: self.arrayLabels[i], duration: 0.2, options: [.transitionCrossDissolve, .curveEaseInOut], animations: {
            self.arrayLabels[i].textColor = color
        })
        
        UIView.transition(with: self.arrayLabels[i - 1], duration: 0.2, options: [.transitionCrossDissolve, .curveEaseInOut], animations: {
            self.arrayLabels[i - 1].textColor = color
        })
    }
    
    // MARK: - Change
    public func change(_ i: Int, changeTo item: QueueItem, _ completion: @escaping () -> ()) {
        highlight(i)
        centerYs[i].isActive = false
        centerYs[i - 1].isActive = false
        
        let bottom1 = arrayLabels[i].bottomAnchor.constraint(equalTo: topAnchor)
        bottom1.isActive = true
        
        let bottom2 = arrayLabels[i - 1].bottomAnchor.constraint(equalTo: topAnchor)
        bottom2.isActive = true
        
        UIView.animate(withDuration: speed, delay: 0, options: .curveEaseInOut, animations: {
            self.layoutIfNeeded()
        }, completion: { (_) in
            if let values = item.values, String(values.0) != self.arrayLabels[i].text || String(values.1) != self.arrayLabels[i - 1].text {
                DispatchQueue.main.asyncAfter(deadline: .now() + self.speed - 0.2) {
                    AudioServicesPlaySystemSound(1105)
                    UIView.transition(with: self.arrayLabels[i], duration: 0.1, options: [.transitionFlipFromLeft, .curveEaseInOut], animations: {
                        self.arrayLabels[i].text = String(values.0)
                    })
                    
                    UIView.transition(with: self.arrayLabels[i - 1], duration: 0.1, options: [.transitionFlipFromRight, .curveEaseInOut], animations: {
                        self.arrayLabels[i - 1].text = String(values.1)
                    })
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + self.speed - 0.2) {
                        bottom1.isActive = false
                        bottom2.isActive = false
                        
                        self.centerYs[i].isActive = true
                        self.centerYs[i - 1].isActive = true
                        
                        UIView.animate(withDuration: self.speed, delay: 0, options: .curveEaseInOut, animations: {
                            self.layoutIfNeeded()
                        }, completion: { (_) in
                            self.highlight(i, with: .label)
                            completion()
                        })
                    }
                }
            } else {
                bottom1.isActive = false
                bottom2.isActive = false
                
                self.centerYs[i].isActive = true
                self.centerYs[i - 1].isActive = true
                
                UIView.animate(withDuration: self.speed, delay: self.speed - 0.3, options: .curveEaseInOut, animations: {
                    self.layoutIfNeeded()
                }, completion: { (_) in
                    self.highlight(i, with: .label)
                    completion()
                })
            }
        })
    }
    
    init(_ array: SortArray, color: UIColor = .label) {
        self.array = array
        arrayLabels = []
        indices = []
        centerYs = []
        
        super.init(frame: .zero)
        clipsToBounds = false
        translatesAutoresizingMaskIntoConstraints = false
        
        var counter = -1
        let w = UILabel()
        w.translatesAutoresizingMaskIntoConstraints = false
        w.font = .monospacedDigitSystemFont(ofSize: 28, weight: .bold)
        w.text = String(array[array.count - 1])
        w.alpha = 0
        addSubview(w)
        
        for value in array {
            counter += 1
            
            let label = UILabel()
            label.translatesAutoresizingMaskIntoConstraints = false
            label.textAlignment = .center
            label.font = .monospacedDigitSystemFont(ofSize: 28, weight: .bold)
            label.text = String(value)
            label.textColor = color
            
            addSubview(label)
            centerYs.append(label.centerYAnchor.constraint(equalTo: centerYAnchor))
            
            if arrayLabels.count == 0 {
                NSLayoutConstraint.activate([
                    label.widthAnchor.constraint(equalTo: w.widthAnchor),
                    centerYs.last!,
                    topAnchor.constraint(equalTo: w.topAnchor),
                    bottomAnchor.constraint(equalTo: w.bottomAnchor)
                ])
            } else {
                NSLayoutConstraint.activate([
                    label.widthAnchor.constraint(equalTo: w.widthAnchor),
                    centerYs.last!,
                    label.leadingAnchor.constraint(equalTo: arrayLabels.last!.trailingAnchor, constant: 16)
                ])
            }
            
            arrayLabels.append(label)
        }
        
        leadingConstraint = leadingAnchor.constraint(equalTo: arrayLabels[0].leadingAnchor, constant: -8)
        trailingConstraint = trailingAnchor.constraint(equalTo: arrayLabels.last!.trailingAnchor, constant: 8)
        
        NSLayoutConstraint.activate([
            leadingConstraint,
            trailingConstraint,
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

// MARK: - Bubble vc
public class BubbleViewController: UIViewController {
    var array: SortArray
    var arrayView: ArrayView!
    public var function: ((SortArray) -> [Int])?
    var items: [QueueItem] = []
    
    let speedUp: UIButton = {
        let button = UIButton(type: .system)
        button.tintColor = .systemBlue
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setImage(UIImage(systemName: "forward.fill")?.applyingSymbolConfiguration(.init(pointSize: 18, weight: .regular)), for: .normal)
        
        button.addTarget(self, action: #selector(speed), for: .touchUpInside)
        return button
    }()
    @objc func speed() {
        arrayView.speed = 0.3
    }
    let startButton: UIButton = {
        let button = UIButton(type: .roundedRect)
        button.tintColor = .systemBlue
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Evaluate", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 24, weight: .medium)
        
        button.addTarget(self, action: #selector(evaluate), for: .touchUpInside)
        return button
    }()
    
    let hintsButton: UIButton = {
        let button = UIButton(type: .roundedRect)
        button.tintColor = .systemBlue
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Show Hints", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 20, weight: .regular)
        
        button.addTarget(self, action: #selector(showHints), for: .touchUpInside)
        return button
    }()
    
    var hints = ["Swap values between `array[j]` and `array[j - 1]`.", "Try creating temporary variable to store one of the comparing values.", """
    Solution:
    ```
    let tmp = array[j]
    array[j] = array[j - 1]
    array[j - 1] = tmp
    ```
    """]
    
    let tutorials = [
        "At first you take two adjacent numbers from array.",
        "Then, if the left number is higher than right, swap the left tand the rght number.",
        "If the right number is higher then left, then do nothing.",
        "Continue this process until the array is sorted."
    ]
    
    // MARK: - ViewDidLoad
    public override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        
        // The playgrounds wouldn't compile a simple layer addition to stored property
        // So here's a hack to fix it...
        let background = UIView()
        background.tag = -1
        view.addSubview(background)
        
        let gradient = CAGradientLayer()
        gradient.frame = view.bounds
        gradient.colors = [
            UIColor(white: 0, alpha: 0).cgColor,
            UIColor(white: 0.8, alpha: 0.2).cgColor
        ]
        
        background.layer.addSublayer(gradient)
        
        arrayView = ArrayView(array)
        
        view.addSubview(arrayView)
        
        NSLayoutConstraint.activate([
            arrayView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            arrayView.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
        
        view.addSubview(startButton)
        view.addSubview(hintsButton)
        startButton.isHidden = true
        view.addSubview(speedUp)
        speedUp.isHidden = true
        NSLayoutConstraint.activate([
            startButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16),
            startButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            hintsButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            hintsButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            speedUp.trailingAnchor.constraint(equalTo: view.readableContentGuide.trailingAnchor),
            speedUp.bottomAnchor.constraint(equalTo: startButton.bottomAnchor, constant: -8)
        ])
        
        if function == nil {
            arrayView.speed = 0.5
        }
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.evaluate()
        }
    }
    
    public override func viewDidLayoutSubviews() {
        // The playgrounds wouldn't compile a simple layer addition to stored property
        // So here's a hack to fix it...
        view.viewWithTag(-1)?.layer.sublayers?.first?.frame = view.bounds
    }
    
    @objc func showHints() {
        PlaygroundPage.current.assessmentStatus = .pass(message: "")
        PlaygroundPage.current.assessmentStatus = .fail(hints: [self.hints[0], self.hints[1]], solution: self.hints[2])
        PlaygroundPage.current.finishExecution()
    }
    
    @objc func restart() {
        startButton.setTitle("Evaluate", for: .normal)
        startButton.removeTarget(nil, action: nil, for: .allEvents)
        startButton.addTarget(self, action: #selector(evaluate), for: .touchUpInside)
        for i in 0..<array.count {
            UIView.transition(with: arrayView.arrayLabels[i], duration: 0.3, options: [.transitionCrossDissolve, .curveEaseInOut], animations: {
                self.arrayView.arrayLabels[i].text = String(self.array[i])
                self.arrayView.arrayLabels[i].textColor = .label
            }, completion: nil)
        }
    }
    
    @objc func evaluate() {
        speedUp.isHidden = false
        startButton.setTitle("Restart", for: .normal)
        startButton.removeTarget(nil, action: nil, for: .allEvents)
        startButton.isHidden = true
        addItems()
        performAnimations()
    }
    
    // MARK: - Perform animations
    var i = 0
    var currentTutorial = 0
    func performAnimations() {
        if let item = items.first {
            let _ = items.removeFirst()
            if currentTutorial < tutorials.count && function == nil {
                PlaygroundPage.current.assessmentStatus = .pass(message: tutorials[currentTutorial])
                currentTutorial += 1
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.8) {
                    self.animate(item) {
                        self.performAnimations()
                        if self.function == nil {
                        }
                        if item.index == self.array.array.count - 1 - self.i {
                            self.i += 1
                            self.arrayView.set(item.index, to: .systemGreen)
                            if self.i == self.array.array.count - 1 {
                                self.arrayView.set(0, to: .systemGreen)
                                self.i = 0
                            }
                        }
                    }
                }
            } else {
                animate(item) {
                    self.performAnimations()
                    if self.function == nil {
                    }
                    if item.index == self.array.array.count - 1 - self.i {
                        self.i += 1
                        self.arrayView.set(item.index, to: .systemGreen)
                        if self.i == self.array.array.count - 1 {
                            self.arrayView.set(0, to: .systemGreen)
                            self.i = 0
                        }
                    }
                }
            }
        } else {
            startButton.addTarget(self, action: #selector(restart), for: .touchUpInside)
            startButton.isHidden = false
            speedUp.isHidden = true
            arrayView.speed = 0.5
            if let result = function?(self.array.copy()), result == bubbleSort(self.array.copy()) {
                AudioServicesPlaySystemSound(1106)
                PlaygroundPage.current.assessmentStatus = .pass(message: "Great work! You can now [continue](@next)!")
            } else {
                PlaygroundPage.current.assessmentStatus = .pass(message: "")
                if function != nil {
                    PlaygroundPage.current.assessmentStatus = .fail(hints: [hints[0], hints[1]], solution: hints[2])
                    AudioServicesPlaySystemSound(1050)
                    let alert = UIAlertController(title: "Error", message: "You have an error in your algorithm. Use a hint!", preferredStyle: .alert)
                    let close = UIAlertAction(title: "Close", style: .cancel)
                    alert.addAction(close)
                    self.present(alert, animated: true, completion: nil)
                } else {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                        PlaygroundPage.current.assessmentStatus = .fail(hints: [self.hints[0], self.hints[1]], solution: self.hints[2])
                        let alert = UIAlertController(title: "Done", message: "You've watched how Bubble sort is performed. Now try to complete missing code in the editor, remember that you can use hints! Please close and open the hints menu to see the new hints.", preferredStyle: .alert)
                        let close = UIAlertAction(title: "Let's go!", style: .default)
                        alert.addAction(close)
                        self.present(alert, animated: true, completion: nil)
                    }
                }
            }
        }
    }
    
    // MARK: - Add items
    func addItems() {
        if let f = function {
            let copy = self.array.copy()
            let _ = f(copy)
            items = copy.queue
        } else {
            let copy = self.array.copy()
            let _ = bubbleSort(copy)
            items = copy.queue
            for i in 0..<items.count {
                items[i].isTutorial = true
            }
        }
    }
    
    // MARK: - Animate
    func animate(_ item: QueueItem, _ completion: @escaping () -> ()) {
        arrayView.change(item.index, changeTo: item, completion)
    }
    
    public init(_ array: [Int]) {
        self.array = SortArray(array)
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
